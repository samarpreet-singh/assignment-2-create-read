<?php
    class database{
        private $servername = "172.31.22.43";
        private $username = "Samarpreet200510621";
        private $password = "sd0JXz34Ay";
        private $database = "Samarpreet200510621";
        public $con;

        public function __construct(){
            $this->con = new mysqli($this->servername, $this->username, $this->password, $this->database);
            if(mysqli_connect_error()){
                trigger_error("Failed to connect:" . mysqli_connect_error());
            }else{
                return $this->con;
            }
        }

        public function createData($post){
            $name = $this->con->real_escape_string($_POST['name']);
            $email = $this->con->real_escape_string($_POST['email']);
            $studentnumber = $this->con->real_escape_string($_POST['studentnumber']);
            $program = $this->con->real_escape_string($_POST['program']);
            $phonenumber = $this->con->real_escape_string($_POST['phonenum']);
            $query = "INSERT INTO enrolledStudents(name,email,student_number,program,phone_number) VALUES ('$name','$email','$studentnumber','$program','$phonenumber')";
            $sql = $this->con->query($query);
            if($sql == true){
                header("Location:index.php?msg1=created"); //we are appending this to the index file if the connection and query work at line 25.
            }else{
                echo "Could not add the student";
            }

        }

        public function displayEnrolled(){
            $query = "SELECT * FROM enrolledStudents";
            $results = $this->con->query($query);
            if($results->num_rows > 0){ // so as long as we have a record in our table, this will run.
                $enrolled = array();
                while($row = $results->fetch_assoc()){ /*
                It can be decoupled in the following steps:
                1 Calculate $row = $results->fetch_assoc() and return array with elements or NULL.
                2 Substitute $row = $results->fetch_assoc() in while with gotten value and get the following statements: while(array(with elements)) or while(NULL).
                3 If it's while(array(with elements)) it resolves the while condition in True and allow to perform an iteration.
                4 If it's while(NULL) it resolves the while condition in False and exits the loop.
                    */
                    $enrolled[] = $row;
                }
                return $enrolled;
            }else{
                echo "No records found";
            }
        }

        public function displayStudentsById($id){
            $query = "SELECT * FROM enrolledStudents WHERE id = '$id'";
            $result = $this->con->query($query);
            if($result->num_rows > 0){ // so as long as we find at least 1 record
                $row = $result->fetch_assoc();
                return $row;
            }else{
                echo "No records found.";
            }
        }

        public function updateStudent($postData){
            $name = $this->con->real_escape_string($_POST['newname']);
            $email = $this->con->real_escape_string($_POST['newemail']);
            $studentnumber = $this->con->real_escape_string($_POST['newstudentnumber']);
            $program = $this->con->real_escape_string($_POST['newprogram']);
            $phonenumber = $this->con->real_escape_string($_POST['newphonenum']);
            $id = $this->con->real_escape_string($_POST['id']);
            if(!empty($id) && !empty($postData)){
                $query = "UPDATE enrolledStudents SET name = '$name', email = '$email', student_number = '$studentnumber', program = '$program', phone_number = '$phonenumber' WHERE id = '$id'";
                $sql = $this->con->query($query);
                if($sql == true){
                    header("Location:view.php?msg2=update");
                }else{
                    echo "Sorry, could not update the record";
                }
            }
        }

        // most dangerous function!
        public function deleteStudent($id){
            $query = "DELETE FROM enrolledStudents WHERE id = '$id'";
            $sql = $this->con->query($query);
            if($sql == true){
                header("Location:view.php?msg3=delete");
            }else{
                echo "Could not delete the record";
            }
        }
    }
?>