<?php
  // include the database file here too
  include 'database.php';
  $studentObj = new database();
  if(isset($_GET['editId']) && !empty($_GET['editId'])){
    $editId = $_GET['editId'];
    $student = $studentObj->displayStudentsById($editId); // storing the particular student in this student variable using the method I created
  }

  if(isset($_POST['update'])){
    $studentObj->updateStudent($_POST); // now if update button is pressed, updateStudent method is called and we get our update done.
  }
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Assignment 2 - Create and read</title>
    <meta name="description" content="This is a create and read assignment!">
    <meta name="robots" content="noindex, nofollow">
    <!-- adding my fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
    <!-- adding Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script> <!--Custom Js Bundle-->
    <!-- adding custom CSS and fontawesome -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
  </head>
  <body>
    <!-- setting up the navbar-->
    <nav class="navbar navbar-expand-lg bg-primary navbar-dark">
        <div class="container">
            <a href="index.php" class="navbar-brand">CRUD Bootcamp Edit Form</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navmenu">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="view.php" class="nav-link">View Enrolled Candidates</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!--navbar ends-->

    <!--Showcase begins-->
    <header class="bg-dark text-light p-5 text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1>Edit <span class="text-warning">Your Information</span> Below!</h1>
                    <p class="lead" my-4>Made a mistake? No worries! You can still edit your information however you see fit!</p>
                </div>
                <img class="img-fluid w-50 d-none d-sm-block" src="./img/header-image.svg" alt="Header Image">
            </div>
        </div>
    </header>

    <?php
    $error = ""; // error validation is required here too as we are again providing info.
            if (empty($name)){
              $error = "Full name is required";
            }else if(empty($program)){
              $error = "Please provide a program name";
            }
            else if(empty($email)){
              $error = "An email is required";
            }
            // the preg_match() function validates the email syntax
            else if(!preg_match("/^[_.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+.)+[a-zA-Z]{2,6}$/i", $email)){ // pattern looks like something@example.com
              $error = "Please use the correct format";
            }else if(empty($phonenum)){
              $error = "Please enter a phone number";
            }
            // is_numeric
            else if(!is_numeric($phonenum)){
              $error = "Please use numbers only";
            }
            // The strlen() function
            else if(strlen($phonenum) != 10){ // if length of phone number is not 10.
              $error = "The phone number must be 10 characters!";
            }else if(empty($studentnumber)){
              $error = "Please enter a student number";
            }
            else if(!is_numeric($studentnumber)){
              $error = "Please use numbers only";
            }
            else if(strlen($studentnumber) != 9){
              $error = "The student number must be 9 characters!";
            }
      ?>

    <section class="bg-white text-dark p-5 text-center" id="form-section">
        <h2>Edit Your Information Here</h2>
        <div class="d-sm-flex" id="form">
            <form action="edit.php" method="POST">
                <div class="form-group">
                  <label for="name">Name:</label>
                  <input type="text" class="form-control" name="newname" value="<?php echo $student['name']; ?>" required> <!-- name has been prefixed with new to pass that info to the update method and echo $student['name'] is used instead of x['name'] because we assigned the entire array to student at the top of this page. I forgot about that and looked around for 30 mins for a typo :') -->
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" name="newemail" value="<?php echo $student['email']; ?>" required>
                </div>
                <div class="form-group">
                  <label for="studentnumber">Student Number:</label>
                  <input type="text" class="form-control" name="newstudentnumber" value="<?php echo $student['student_number']; ?>" required>
                </div>
                  <div class="form-group">
                    <label for="program">Program:</label>
                    <input type="text" class="form-control" name="newprogram" value="<?php echo $student['program']; ?>"required>
                  </div>
                  <div class="form-group">
                    <label for="phonenum">Contact Number:</label>
                    <input type="text" class="form-control" name="newphonenum" value="<?php echo $student['phone_number']; ?>" required>
                  </div>
                  <div class="form-group">
                    <input type="hidden" name="id" value="<?php echo $student['id']; ?>">
                    <input type="submit" name="update" class="btn btn-primary" value="Update">
                  </div>
              </form>
        </div>
    </section>
    
    <footer class="p-5 bg-dark text-center text-white">
        <div class="container">
            <p class="lead">Copyright &copy; 2022 CRUD Bootcamp</p>
        </div>
    </footer>

  </body>