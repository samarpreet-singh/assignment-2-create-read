CREATE TABLE enrolledStudents (
    id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name varchar(100) NOT NULL,
    email varchar(100) NOT NULL,
    student_number varchar(100) NOT NULL,
    program varchar(100) NOT NULL,
    phone_number varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;