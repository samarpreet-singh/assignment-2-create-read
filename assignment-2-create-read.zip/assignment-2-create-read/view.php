<?php
  // include the database file
  include 'database.php';
  $studentObj = new database();
  //adding the delete function
  if(isset($_GET['deleteId']) && !empty($_GET['deleteId'])){
    $deleteId = $_GET['deleteId']; //deleteId at line 110 gets stored in this variable and then the variable is passed to the deleteStudent method I created in database.php
    $studentObj->deleteStudent($deleteId);
  }
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Assignment 2 - Create and read</title>
    <meta name="description" content="This is a create and read assignment!">
    <meta name="robots" content="noindex, nofollow">
    <!-- adding my fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
    <!-- adding Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script> <!--Custom Js Bundle-->
    <!-- adding custom CSS and fontawesome -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
  </head>
  <body>
    <!-- setting up the navbar again-->
    <nav class="navbar navbar-expand-lg bg-primary navbar-dark">
        <div class="container">
            <a href="index.php" class="navbar-brand">Create and Read Form</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navmenu">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="view.php" class="nav-link">View Enrolled Candidates</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!--Showcase begins-->
    <header class="bg-light text-dark p-5 text-center text-sm-start">
        <?php
        if(isset($_GET['msg2']) == "update"){
            echo "<div class='alert alert-success alert-dismissible'>
                <button type='button' class='close' data-dismiss='alert'>X</button>
                Your information has been updated!
              </div>";
          }
          if(isset($_GET['msg3']) == "delete"){ // no need to put the create message here because that is only done on the index page.
            echo "<div class='alert alert-success alert-dismissible'>
                <button type='button' class='close' data-dismiss='alert'>X</button>
                Your registration has been cancelled. You can register again if you wish to!
              </div>";
          } 
        ?>
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1>List of <span class="text-warning">Enrolled</span> Candidates!</h1>
                    <p class="lead" my-4>Below is the list of students who are currently enrolled in the free web development course! </p>
                </div>
                <img class="img-fluid w-50 d-none d-sm-block" src="./img/header-image-view.svg" alt="Header Image">
            </div>
        </div>
    </header>
    <section class="bg-light text-dark text-center">
        <div class="container">
            <h2>Enrolled Candidates List
            </h2>
            <table class="table table-hover table-light table-striped">
            <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Student Number</th>
                <th>Program</th>
                <th>Phone Number</th>
                <th>Modify</th>
            </tr>
            </thead>
            <tbody>
                <?php
                $students = $studentObj->displayEnrolled();
                foreach($students as $x){ // this loop will loop through all the items in students
                    ?>
                    <tr>
                        <td><?php echo $x['id'] ?></td>
                        <td><?php echo $x['name'] ?></td>
                        <td><?php echo $x['email'] ?></td>
                        <td><?php echo $x['student_number'] ?></td>
                        <td><?php echo $x['program'] ?></td>
                        <td><?php echo $x['phone_number'] ?></td>
                        <td>
                        <button class="btn btn-primary">
                            <a href="edit.php?editId=<?php echo $x['id'] ?>"> <!--The edit ID variable will be populated with id once the edit button is pressed and then the code on the top of this file gets executed.-->
                                <i class="fa fa-pencil text-dark"></i> <!-- using font awesome to get icons for the button -->
                            </a>
                            </button>
                            <button class="btn btn-danger">
                            <a href="view.php?deleteId=<?php echo $x['id'] ?>" onclick="confirm('Be absolutely certain before you do this! Data will be WIPED!')"> <!-- make sure to give warnings before delete. Protect users from themselves -->
                                <i class="fa fa-trash text-dark"></i>
                            </a>
                            </button>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            </table>
        </div>
    </section>

    <footer class="p-5 bg-dark text-center text-white">
        <div class="container">
            <p class="lead">Copyright &copy; 2022 CRUD Bootcamp</p>
        </div>
    </footer>