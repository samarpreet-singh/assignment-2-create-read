<!--Student Name : Samarpreet Singh-->
<!--Student Number : 200510621 -->
<!--Program: Computer Programming -->
<?php
  // including the database file
  include 'database.php';
  $studentObj = new database();
  if(isset($_POST['submit'])){
    $studentObj->createData($_POST); // createData method is called to insert data into the table.
  }

  // there will be some personal notes below where I noted down the new things I learned while doing this.
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Assignment 2 - Create and read</title>
    <meta name="description" content="This is a create and read assignment!">
    <meta name="robots" content="noindex, nofollow">
    <!-- adding my fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,400;0,700;1,400&family=Poppins:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
    <!-- adding Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script> <!--Custom Js Bundle-->
    <!-- adding custom CSS and fontawesome -->
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
  </head>
  <body>
    <?php
      if(isset($_GET['msg1']) == "created"){ // using get, we check url and if url matches insert at the end, then we say record has been created
        echo "<div class='alert alert-success alert-dismissible'>
            <button type='button' class='close' data-dismiss='alert'>X</button>
            You have been registered!
          </div>";
      }
      // update and delete are on view.php
    ?>
    <!-- setting up the navbar-->
    <nav class="navbar navbar-expand-lg bg-primary navbar-dark">
        <div class="container">
            <a href="index.php" class="navbar-brand">CRUD Bootcamp Enrollment Form</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navmenu">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="view.php" class="nav-link">View Enrolled Candidates</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!--navbar ends-->

    <!--Header begins-->
    <header class="bg-dark text-light p-5 text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1>Add <span class="text-warning">Your Information</span> Below!</h1>
                    <p class="lead" my-4>Enter your name, program, student number, email, and phone number in the form below to be enrolled in a free web development course!</p>
                    <button class="btn btn-primary btn-lg"><a href="#form" id="link">Take me there!</a></button>
                </div>
                <img class="img-fluid w-50 d-none d-sm-block" src="./img/header-image.svg" alt="Header Image">
            </div>
        </div>
    </header>

    <!--error validation-->
    <?php
      $error = "";
      if (empty($name)){
       $error = "Full name is required";
      }else if(empty($program)){
       $error = "Please provide a program name";
      }
      else if(empty($email)){
        $error = "An email is required";
      }
      // the preg_match() function validates the email syntax
      else if(!preg_match("/^[_.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+.)+[a-zA-Z]{2,6}$/i", $email)){ // pattern looks like something@example.com
        $error = "Please use the correct format";
      }else if(empty($phonenum)){
        $error = "Please enter a phone number";
      }
      // is_numeric
      else if(!is_numeric($phonenum)){
       $error = "Please use numbers only";
      }
      // The strlen() function
      else if(strlen($phonenum) != 10){ // if length of phone number is not 10.
        $error = "The phone number must be 10 characters!";
      }else if(empty($studentnumber)){
        $error = "Please enter a student number";
      }
      else if(!is_numeric($studentnumber)){
        $error = "Please use numbers only";
      }
      else if(strlen($studentnumber) != 9){
        $error = "The student number must be 9 characters!";
      }
    ?>

<!--form begins-->
    <section class="bg-white text-dark p-5 text-center" id="form-section">
        <h2>Enrollment Form</h2>
        <div class="d-sm-flex" id="form">
            <form action="index.php" method="POST">
                <div class="form-group">
                  <label for="name">Name:</label>
                  <input type="text" class="form-control" name="name" placeholder="Enter full name" required>
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" name="email" placeholder="Enter email" required>
                </div>
                <div class="form-group">
                  <label for="studentnumber">Student Number:</label>
                  <input type="text" class="form-control" name="studentnumber" placeholder="Enter Student Number" required>
                </div>
                <div class="form-group">
                    <label for="program">Program:</label>
                    <input type="text" class="form-control" name="program" placeholder="Enter program" required>
                  </div>
                  <div class="form-group">
                    <label for="phonenum">Contact Number:</label>
                    <input type="text" class="form-control" name="phonenum" placeholder="Enter your phone number" required>
                  </div>
                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
              </form>
        </div>
    </section>
    
    <!--footer -->
    <footer class="p-5 bg-dark text-center text-white">
        <div class="container">
            <p class="lead">Copyright &copy; 2022 CRUD Bootcamp</p>
        </div>
    </footer>

  </body>